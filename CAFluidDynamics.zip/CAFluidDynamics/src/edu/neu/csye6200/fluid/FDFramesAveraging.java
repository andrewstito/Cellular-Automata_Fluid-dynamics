/**
 * 
 */
package edu.neu.csye6200.fluid;

/**
 * @author Andrews Tito
 *
 */
public class FDFramesAveraging {
	private double[][] direction;
	private double[][] magnitude;
	private int size;
	
	public FDFramesAveraging(int size){
		direction = new double[size][size];
		magnitude = new double[size][size];
		this.size = size;
		initArray();
	}
	
	public void setFluidFrame(FDFluidFrame inFrame)
	{
		int stepSize = inFrame.size / size;
				
		for(int x = 0; x < size; x++) {
			for(int y = 0; y < size; y++) {
				inFrame.getAverageRegion(y * stepSize, x * stepSize, stepSize);
				direction[x][y]= inFrame.getAverageDirection();
				magnitude[x][y]= inFrame.getAverageMagnitude();
			 }	
		}
	}
		
	private void initArray() {
		for(int x = 0; x < size; x++) {
			for(int y = 0; y < size; y++) {
				direction[x][y]= 0.0;
				magnitude[x][y]= 0.0;
			}
		}
	}
	
	public void displayDirection() {
		System.out.println(" Direction Value :");
		for(int x = 0; x < size; x++) {
			for(int y = 0; y < size; y++) {
				System.out.print(" " +direction[x][y]);
			}
			System.out.println("");
		}
	}
	 
	public void displayMagnitude() {
		System.out.println(" Magnitude Value is:");
		for(int x = 0; x < size; x++) {
			for(int y = 0; y < size; y++) {
				System.out.print(" " +magnitude[x][y]);
			}
			System.out.println("");
		}
		
	}

	public int getSize() {
		return size;
	}

	public double getDirection(int i, int j) {
		return direction[i][j];
	}

	public double getMagnitude(int i, int j) {
		return magnitude[i][j];
	}
}




