/**
 * 
 */
package edu.neu.csye6200.fluid;

import java.util.logging.Logger;

import edu.neu.csye6200.ui.UIBGCanvas;

/**
 * @author
 *
 */
public class FDRules extends RuleA {

	private Logger _log = Logger.getLogger(FDRules.class.getName());
	// Constructor
	public FDRules(int size) {
		this.size= size;
	}

	@Override
	public int createNextCell(int inVal, int x, int y, int size) {

		//_log.info("Default rule accessed.");
		int outVal = 0;
		
		switch (inVal) {
		// for 2 particle
		case 0b001001: outVal = 0b100100; break;
		case 0b010010: outVal = 0b001001; break;
		case 0b100100: outVal = 0b010010; break;
		
		// for 4 particle
		case 0b110110: outVal = 0b011011; break;
		case 0b011011: outVal = 0b101101; break;
		case 0b101101: outVal = 0b110110; break;
		
		// for 3 particle
		case 0b010101: outVal = 0b010101; break; // same direction reflected
		case 0b101010: outVal = 0b101010; break; // "		"			"
		
		case 0b000111: outVal = 0b111000; break; //  
		case 0b001011: outVal = 0b110100; break;
		case 0b001101: outVal = 0b110010; break;
		case 0b001110: outVal = 0b110001; break;
		case 0b010011: outVal = 0b101100; break;
		case 0b010110: outVal = 0b101001; break;
		case 0b011001: outVal = 0b100110; break;
		case 0b011010: outVal = 0b100101; break;
		case 0b011100: outVal = 0b100011; break;
		case 0b100011: outVal = 0b011100; break;
		case 0b100101: outVal = 0b011010; break;
		case 0b100110: outVal = 0b011001; break;
		case 0b101001: outVal = 0b010110; break;
		case 0b110001: outVal = 0b001110; break;
		case 0b110010: outVal = 0b001101; break;
		case 0b110100: outVal = 0b001011; break;
		case 0b111000: outVal = 0b000111; break;
		case 0b101100: outVal = 0b010011; break;
		 
		default:
			outVal = defNextCell(inVal);	// default cell collision : 
			break;
		}
		outVal = setEdgeReflection(outVal, x, y, size);
		return outVal;
		
		
	}
	
	public int createNextCell2P(int inVal, int x, int y, int size) {

		//_log.info("2 Particle rule accessed.");
		int outVal = 0;
		
		switch (inVal) {
		// for 2 particle
		case 0b001001: outVal = 0b100100; break;
		case 0b010010: outVal = 0b001001; break;
		case 0b100100: outVal = 0b010010; break;
		
		default:
			outVal = defNextCell(inVal);	// default cell collision : 
			break;
		}
		outVal = setEdgeReflection(outVal, x, y, size);
		return outVal;
		
	}
	
	public int createNextCell4P(int inVal, int x, int y, int size) {

		//_log.info("4 Particle rule accessed.");
		int outVal = 0;
		
		switch (inVal) {
		
		// for 4 particle
		case 0b110110: outVal = 0b011011; break;
		case 0b011011: outVal = 0b101101; break;
		case 0b101101: outVal = 0b110110; break;
		
		default:
			outVal = defNextCell(inVal);	// default cell collision : 
			break;
		
		}
		outVal = setEdgeReflection(outVal, x, y, size);
		return outVal;
	}
	
	public int createNextCell3P(int inVal, int x, int y, int size) {

		//_log.info("3 Particle rule accessed.");
		int outVal = 0;
		
		switch (inVal) {
		
		// for 3 particle
		case 0b010101: outVal = 0b010101; break; // same direction reflected
		case 0b101010: outVal = 0b101010; break; // "		"			"
		
		case 0b000111: outVal = 0b111000; break; //  opposite bits turned on 
		case 0b001011: outVal = 0b110100; break; //  "              "
		case 0b001101: outVal = 0b110010; break;
		case 0b001110: outVal = 0b110001; break;
		case 0b010011: outVal = 0b101100; break;
		case 0b010110: outVal = 0b101001; break;
		case 0b011001: outVal = 0b100110; break;
		case 0b011010: outVal = 0b100101; break;
		case 0b011100: outVal = 0b100011; break;
		case 0b100011: outVal = 0b011100; break;
		case 0b100101: outVal = 0b011010; break;
		case 0b100110: outVal = 0b011001; break;
		case 0b101001: outVal = 0b010110; break;
		case 0b110001: outVal = 0b001110; break;
		case 0b110010: outVal = 0b001101; break;
		case 0b110100: outVal = 0b001011; break;
		case 0b111000: outVal = 0b000111; break;
		case 0b101100: outVal = 0b010011; break;
		
		default:
			outVal = defNextCell(inVal);	// default cell collision : 
			break;
		}
		outVal = setEdgeReflection(outVal, x, y, size);
		return outVal;
	}

			
	public int defNextCell(int inVal) {	
		
		int outVal = 0;
		for (int dir = 0; dir < 6; dir++) {

			if (FDParticleCell.hasDirectionFlag(inVal, dir))
				outVal = FDParticleCell.setFlag(outVal, FDParticleCell.getOppositeDirection(dir)); // Just pass through in the opposite direction from where it came
		}

		return outVal;
		
	}

}
