
package edu.neu.csye6200.fluid;

import edu.neu.csye6200.ui.ATApp;

/**
 * @author Andrews Tito (built on top of template helper code)
 *
 */

	public class RuleA implements RuleI {

		private boolean upperEdge 	   = false; 
		private boolean lowerEdge 	   = false;
		private boolean leftEdge 	   = false;
		private boolean rightEdge 	   = false;
		private boolean upperLeftEdge  = false;
		private boolean lowerLeftEdge  = false;
		private boolean upperRightEdge = false; 
		private boolean lowerRightEdge = false;
		
		protected int size = 0;
		
		int nextOutCelVal;
		public static int ruleChosen = 0;
				
	public RuleA() {
	} 

	/* (non-Javadoc)
	 * @see edu.neu.csye6200.fluid.RuleI#createNextFrame(edu.neu.csye6200.fluid.FluidFrame)
	 */
	@Override
	public FDFluidFrame createNextFrame(FDFluidFrame inFrame) {
		FDFluidFrame nxtFrame = new FDFluidFrame(inFrame.getSize());
		
		for (int x = 0; x < inFrame.getSize(); x++) {
			for (int y = 0; y < inFrame.getSize(); y++) {
				int inboundVal = inFrame.getCellInValue(x, y); // Read all neighbors and create opposite inbound values from their outbound ones
				
				// nextOutCelVal created based on the Collision rule selected
				ruleChosen = ATApp.checkOption;
				if (ruleChosen == 2) 
					nextOutCelVal = createNextCell2P(inboundVal, x, y, inFrame.getSize()); 
				else if (ruleChosen == 3) 
					nextOutCelVal = createNextCell3P(inboundVal, x, y, inFrame.getSize()); 
				else if (ruleChosen == 4) 
					nextOutCelVal = createNextCell4P(inboundVal, x, y, inFrame.getSize()); 
				else nextOutCelVal = createNextCell(inboundVal, x, y, inFrame.getSize()); 
						
				// Checking for boundary edge
				if(checkEdge(x,y,inFrame.getSize())) {
				
					nextOutCelVal = setEdgeReflection(nextOutCelVal, x, y, inFrame.getSize());
				
			}
							
				nxtFrame.setCellOutValue(x, y, nextOutCelVal);
			}
		}
		return nxtFrame;
	}

	public boolean checkEdge(int x, int y, int size) {
		
		if 	(x <= 0) 		return true;
		if 	(y <= 0) 		return true; 
		if	(x >= (size-1)) return true; 
		if	(y >= (size-1)) return true;
		return false;
	}
	
	public int setEdgeReflection(int nextOutCelVal, int x, int y, int size) {
			
		upperEdge 	   = checkTop(x, y);
		lowerEdge 	   = checkBottom(x, y);
		leftEdge 	   = checkLeft(x, y);
		rightEdge 	   = checkRight(x, y);
		upperLeftEdge  = checkTopLeft(x, y);
		lowerLeftEdge  = checkBottomLeft(x, y);
		upperRightEdge = checkTopRight(x, y);
		lowerRightEdge = checkBottomRight(x, y);
		
		for (int dir = 0; dir < 6; dir++) {
			if ((y & 1) == 0) { // y is even
				
				switch (dir) {
				default:
					
				case 0:	// Particle movement direction (0 - Left)
					if (checkBoundary(x - 1, y, size)) {
						if (lowerLeftEdge) 	nextOutCelVal 	  = updateEdgeReflection(nextOutCelVal, dir, 2);
						else if (upperLeftEdge)	nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 4);
						else if (leftEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 3);
					}
					break; 
				
				case 1:	// Particle movement direction (1 - Upper Left)
					if (checkBoundary(x - 1, y - 1, size)) {
						if (upperLeftEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 3);
						else if (upperRightEdge)nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 5);
						else if (leftEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 2);
						else if (upperEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 5);
					}
					break; 
				
				case 2: // Particle movement direction (2 - Upper Right)
					if (checkBoundary(x, y - 1, size)) {
						if (upperRightEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 4);
						else if (upperEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 4);
					}
					break; 
					
				case 3: // Particle movement direction (3 - Right)
					if (checkBoundary(x + 1, y, size)) {
						if (upperRightEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 5);
						else if (lowerRightEdge)nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 1);
						else if (rightEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 0);
					}
					break; 
					
				case 4:	// Particle movement direction (4 - Lower Right)
					if (checkBoundary(x, y + 1, size)) {
						if (lowerLeftEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 2);
						else if (lowerRightEdge)nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 0);
						else if (lowerEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 2);
					}
					break; 
					
				case 5:	// Particle movement direction (5 - Lower Left)
					if (checkBoundary(x - 1, y + 1, size)) {
						if (lowerLeftEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 1);
						else if (leftEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 4);
						else if (lowerEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 1);
					}
					break; 
				}
				
			} else { // y is odd
				switch (dir) {
				default:
				
				case 0: // Particle movement direction (0 - Left)
					if (checkBoundary(x - 1, y, size)) {
						if (lowerLeftEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 2);
						else if (leftEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 3);
					}
					break; 
				
				case 1: // Particle movement direction (1 - Upper Left)
					if (checkBoundary(x, y - 1, size)) {
						if (upperEdge)			nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 5);
					}
					break; 
				
				case 2: // Particle movement direction (2 - Upper Right)
					if (checkBoundary(x + 1, y - 1, size)) {
						if (rightEdge)			nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 1);
						else if (upperEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 4);
					}
					break; 
				
				case 3: // Particle movement direction (3 - Right)
					if (checkBoundary(x + 1, y, size)) {
						if (lowerRightEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 1);
						else if (rightEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 0);
					}
					break;
				case 4: // Particle movement direction (4 - Lower Right)
					if (checkBoundary(x + 1, y + 1, size)) {
						if (lowerRightEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 0);
						else if (rightEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 5);
						else if (lowerEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 2);
					}
					break; 
				case 5: // Particle movement direction (5 - Lower Left)
					if (checkBoundary(x, y + 1, size)) {
						if (lowerLeftEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 3);
						else if (lowerRightEdge)nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 1);
						else if (lowerEdge)		nextOutCelVal = updateEdgeReflection(nextOutCelVal, dir, 1);
					}
					break; 
				}

			}
		
		}
		
		return nextOutCelVal;
		
	}
	
	public int updateEdgeReflection(int nextOutCelVal, int dir, int newDir) {
		if (FDParticleCell.hasDirectionFlag(nextOutCelVal, dir)) { 
			nextOutCelVal = FDParticleCell.setFlag(nextOutCelVal, newDir);
			nextOutCelVal = FDParticleCell.removeFlag(nextOutCelVal, dir);
		}
		return nextOutCelVal;
	}
	
	public boolean checkBoundary(int x, int y, int size) {
		if 	(x < 0) 	return true;
		if 	(y < 0)    	return true; 
		if	(x >= size) return true; 
		if	(y >= size) return true;
		return false;
	}

	private boolean checkRight(int x, int y) {
		if ((y > 0 && y < (size - 1)) && x == (size - 1)) return true;
		return false;
	}

	private boolean checkLeft(int x, int y) {
		if ((y > 0 && y < (size - 1)) && x == 0) return true;
		return false;
	}

	private boolean checkBottom(int x, int y) {
		if ((x > 0 && x < (size - 1)) && y == (size - 1)) return true;
		return false;
	}

	private boolean checkTop(int x, int y) {
		if ((x > 0 && x < (size - 1)) && y == 0) return true;
		return false;
	}

	private boolean checkBottomRight(int x, int y) {
		if (x == (size - 1) && y == (size - 1)) return true;
		return false;
	}

	private boolean checkTopRight(int x, int y) {
		if (x == (size - 1) && y == 0) return true;
		return false;
	}

	private boolean checkBottomLeft(int x, int y) {
		if (x == 0 && y == (size - 1)) return true;
		return false;
	}

	private boolean checkTopLeft(int x, int y) {
		if (x == 0 & y == 0) return true;
		return false;
	}

	
	/* 
	 * Rules that handle collisions based on number of incoming particles
	 */
	@Override
	public int createNextCell(int inVal, int x, int y, int size) {
		return inVal;
	}
	
	public int defNextCell(int inVal, int x, int y, int size) {
		return inVal;
	}
	
	public int createNextCell2P(int inVal, int x, int y, int size) {
		return inVal;
	}
	
	public int createNextCell3P(int inVal, int x, int y, int size) {
		return inVal;
	}
	
	public int createNextCell4P(int inVal, int x, int y, int size) {
		return inVal;
	}

}
