
package edu.neu.csye6200.fluid;
import java.util.Observable;
import java.util.Observer;

import edu.neu.csye6200.ui.*;

import edu.neu.csye6200.ui.ATApp;

/**
 * A single frame of a Cellular Automata Fluid dynamics Frame
 * 
 * @author Andrews Tito (built on top of template helper code)
 */
public class FluidFrameSim extends Observable implements Runnable {

	private boolean done = false; // Set true to exit (i.e. stop) the simulation
	private static boolean paused = false; // Set true to pause the simulation

	private int MAX_FRAME_SIZE = 750; // How big is the simulation frame
	private int MAX_GENERATION = 5; // How many generations will we calculate before we're through?
	private int genCount = 0; // the count of the most recent generation

	private FDFluidFrame currentFrame = null;
	private FDFramesAveraging avgFrames = null;
	private UIFDApp uifd = null;
	
	private RuleA rule = null;

	/**
	 * 
	 */
	public FluidFrameSim(int maxGen) {
		MAX_GENERATION = maxGen; // User given max no of generation value taken from GUI
		currentFrame = new FDFluidFrame(MAX_FRAME_SIZE);
		currentFrame.addRandomParticles(0.2); // Only 20% of the cells should have a particle
		
		rule = new FDRules(MAX_FRAME_SIZE);
		avgFrames = new FDFramesAveraging(MAX_FRAME_SIZE / 10);
	}

	public void runSim() {

		System.out.println("FluidFrame: 0");
		/*
		 * Enable/Disable below "currentFrame.drawFrameToConsole();" to draw first frame to console.
		 * Please note enabling this will reflect a start delay in the once the APP is started execution
		 */
		//currentFrame.drawFrameToConsole(); 

		while (!done) {

			if(!paused) {

			FDFluidFrame nextFrame = rule.createNextFrame(currentFrame);
			
			/*
			 *Averaging and storing the results to create a lower-res display frame 
			 */
			avgFrames.setFluidFrame(nextFrame); // 

			
			/*
			 * Advertise that we have a display displayable average FluidFrame and let it be drawn
			 */
			setChanged();
	        notifyObservers(avgFrames);

			genCount++; // Keep track of how many frames have been calculated
			//System.out.println("\nFluidFrame: " + genCount);
			//nextFrame.drawFrameToConsole();	// Enable this to print the generated frames onto the consoles
			
			currentFrame = nextFrame;
			int speedCount = 0;
			speedCount = ATApp.speedOption;
			
			try {
				if (speedCount == 1)	Thread.sleep(500);
				else if (speedCount == 2)	Thread.sleep(250);
				else if (speedCount == 3)	Thread.sleep(100);
				else Thread.sleep(10);
//				Thread.sleep(10);	// modifying this value varies the speed of particles on the Canvas
			} catch (InterruptedException e) {
				System.out.println("Thread ERROR at FluidFrameSim");
			}

			if (genCount > MAX_GENERATION)	done = true;
						
	        
			}
			else
			{
				try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
				
			}
			
		}
		ATApp.resetButtons();
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		UIBGCanvas obsCanvas = new UIBGCanvas();
		addObserver(obsCanvas);
		runSim();
	}
	
	public static void pauseSimulation() {
		paused = true;
	}
	public static void resumeSimulation() {
		paused = false;
	}

}
