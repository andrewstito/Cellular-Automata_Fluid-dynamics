
package edu.neu.csye6200.fluid;

/**
 * A Rule defines how to generate a new FluidFrame from an existing one
 * /**
 * @author Andrews Tito (built on top of template helper code)
 */
 
 public interface RuleI {

	public FDFluidFrame createNextFrame(FDFluidFrame inFrame);
	public int createNextCell(int inVal, int x, int y, int size);
	public int createNextCell2P(int inVal, int x, int y, int size);
	public int createNextCell3P(int inVal, int x, int y, int size);
	public int createNextCell4P(int inVal, int x, int y, int size);
	public int defNextCell(int inVal, int x, int y, int size);
	
}
