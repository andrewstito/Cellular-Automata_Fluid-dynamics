package edu.neu.csye6200.ui;


import javax.swing.Action;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.text.DefaultEditorKit;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;

/**
 * A sample Biological Growth Abstract application class
 * @author Andrews Tito (built on top of template helper code)
 */
public abstract class UIFDApp implements ActionListener, WindowListener {
	protected JFrame frame = null;
	protected UIMenuManager menuMgr = null;

	/**
	 * The Biological growth constructor
	 */
	public UIFDApp() {
		initGUI();
	}
	
	/**
	 * Initialize the Graphical User Interface
	 */
    public void initGUI() {
    	frame = new JFrame();
		frame.setTitle("BGApp");

		frame.setResizable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //JFrame.DISPOSE_ON_CLOSE)
		
		// Permit the app to hear about the window opening
		frame.addWindowListener(this); 
		
		menuMgr = new UIMenuManager(this);
		
		frame.setJMenuBar(menuMgr.getMenuBar()); // Add a menu bar to this application
		
		frame.setLayout(new BorderLayout());
		frame.add(getMainPanel(), BorderLayout.CENTER);
    }
    
    /**
     * Override this method to provide the main content panel.
     * @return a JPanel, which contains the main content of of your application
     */
    public abstract JPanel getMainPanel() ;

    
    /**
     * A convenience method that uses the Swing dispatch threat to show the UI.
     * This prevents concurrency problems during component initialization.
     */
    public void showUI() {
    	
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
            	frame.setVisible(true); // The UI is built, so display it;
            }
        });
    	
    }
    
    /**
     * Shut down the application
     */
    public void exit() {
    	frame.dispose();
    	System.exit(0);
    }

    /**
     * Override this method to show a About Dialog
     */
    public void showHelp() {
    	Component frame = null;
		JOptionPane.showMessageDialog(frame,
			    "\r\n" + 
			    "Cellular Automata :: Fluid Dynamics\r\n" + 
			    "\r\n"+ 
			    "This is a simple cellular automaton simulation system set up to emulate the microscopic behavior of \r\n" +
			    "molecules in a fluid. At each step the configuration of particles is updated according to the simple\r\n" + 
			    "collision rules setup in the program.\r\n" + 
			    "\r\n"+
			    "Core Idea:: Stephen Wolfram's - A New Kind of Science\r\n" + 
			    "For more info, visit: http://www.wolframscience.com/nks/p378--fluid-flow/\r\n" + 
			    "\r\n" + 
			    "Created by :\r\n" +
			    "Andrews Tito  (NUID : 001837549)\r\n" + 
			    "CSYE6200 33701 SEC 01 : Concepts of Object Oriented Design in JAVA by Prof. Mark Munson\r\n" +
			    "Northeastern University\r\n");
		
		
    }
     
    /**
     * Minimize or Undock the Window display
     */
    public void minimizeWindow() {
    	frame.setState(JFrame.ICONIFIED);

    }
    
    public void execComplete() {
    	Component frame = null;
		JOptionPane.showMessageDialog(frame,
				"Execution Completed\r\n"+
				"\r\n");		
		
    }
    
}
