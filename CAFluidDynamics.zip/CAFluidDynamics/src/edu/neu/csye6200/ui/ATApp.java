package edu.neu.csye6200.ui;
import edu.neu.csye6200.fluid.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;
import java.util.logging.Logger;

import javax.swing.ComboBoxModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 * An application for the Wolfram Fluid flow application
 * @author Andrews Tito (built on top of template helper code)
 */
public class ATApp extends UIFDApp implements ActionListener, Observer, Runnable, WindowListener {

	private static Logger log = Logger.getLogger(ATApp.class.getName());
	public static UIBGCanvas 	bgPanel 	= null;
	private FluidFrameSim ffSim = null;
	private Thread simThread = null;
		
	protected JPanel 	mainPanel 	= null;
	protected JPanel 	northPanel	= null;
	protected static JButton 	startBtn;
	protected static JButton 	stopBtn;
    protected static JButton   	pauseBtn;
    protected static JButton   	resumeBtn;
    protected JLabel    ruleLabel, genLabel, genLabel2, speedLabel, speedLabel2, partLabel, partLabel2;
    protected static JComboBox<String> ruleComboBox, speedComboBox, particleComboBox;
    protected static JTextField genCount;
       
    public static int checkOption = 0, speedOption = 0, particleOption = 0;
    public static int count, speed;

    
   // Constructor
    public ATApp() {
    	frame.setSize(1000, 400); // initial Frame size
		frame.setTitle("Cellular Automata :: Fluid Dynamics");
		
		menuMgr.createDefaultActions(); // Set up default menu items
		
    	showUI(); // Cause the Swing Dispatch thread to display the JFrame
    }
   
    /**
     * A main panel that will hold the bulk of our application display
     */
	@Override
	public JPanel getMainPanel() {
	
		mainPanel = new JPanel();
    	mainPanel.setLayout(new BorderLayout());
    	mainPanel.add(BorderLayout.NORTH, getNorthPanel());
    	
    	bgPanel = new UIBGCanvas();
    	mainPanel.add(BorderLayout.CENTER, bgPanel);
    	
    	return mainPanel;
	}
    
	/**
	 * A top panel that will hold control buttons
	 * @return
	 */
	
    public JPanel getNorthPanel() {
    	    	
    	northPanel = new JPanel();
    	northPanel.setLayout(new FlowLayout());
    	northPanel.setBackground(Color.GRAY);
    	
    	// For Rule selection
    	ruleLabel = new JLabel("Rule List   ");
    	northPanel.add(ruleLabel);
     	ruleComboBox = new JComboBox<String>();
    	ruleComboBox.addItem("Default Rule");
    	ruleComboBox.addItem("2 particle collision");
    	ruleComboBox.addItem("3 particle collision");
    	ruleComboBox.addItem("4 particle collision");
    	northPanel.add(ruleComboBox);
    	
    	// For Number of generations
    	genLabel = new JLabel("    No.of Generations: ");
    	northPanel.add(genLabel);
    	genCount = new JTextField("10");
    	northPanel.add(genCount);
    	genLabel2 = new JLabel("     ");
    	northPanel.add(genLabel2);
    	
    	// For Speed of fluid flow simulation
    	speedLabel = new JLabel("Speed: ");
    	northPanel.add(speedLabel);
    	speedComboBox = new JComboBox<String>();
    	speedComboBox.addItem(" 1x ");
    	speedComboBox.addItem(" 2x ");
    	speedComboBox.addItem(" 3x ");
    	speedComboBox.addItem(" 4x ");
    	northPanel.add(speedComboBox);
    	speedLabel2 = new JLabel("   ");
    	northPanel.add(speedLabel2);
    	
    	partLabel = new JLabel("Particle Size: ");
    	northPanel.add(partLabel);
    	particleComboBox = new JComboBox<String>();
    	particleComboBox.addItem(" 1 ");
    	particleComboBox.addItem(" 2 ");
    	particleComboBox.addItem(" 3 ");
    	particleComboBox.addItem(" 4 ");
    	northPanel.add(particleComboBox);
    	partLabel = new JLabel("   ");
    	northPanel.add(partLabel);
    	
    	startBtn = new JButton("Start");
    	northPanel.add(startBtn);
    	
    	pauseBtn = new JButton("Pause");
    	northPanel.add(pauseBtn);
    	pauseBtn.setEnabled(false);
    	
    	resumeBtn = new JButton("Resume");   	
    	northPanel.add(resumeBtn);
    	resumeBtn.setEnabled(false);
    	
    	stopBtn = new JButton("Stop");
    	northPanel.add(stopBtn);
    	stopBtn.setEnabled(false);
   	  	 
    	ruleComboBox.addActionListener(this);
    	startBtn.addActionListener(this);
    	stopBtn.addActionListener(this);
    	pauseBtn.addActionListener(this);
    	resumeBtn.addActionListener(this);
    	stopBtn.addActionListener(this);
    	speedComboBox.addActionListener(this);
    	particleComboBox.addActionListener(this);
    	   	
    	return northPanel;
    }
    
	@Override
	synchronized public void actionPerformed(ActionEvent ae) {
		log.info("An ActionEvent performed" + ae);
		
		count = Integer.parseInt(genCount.getText());
		if (count <= 0) count = 35;
		
		if (ae.getSource() == startBtn) {
			System.out.println("Start pressed");
			
			ffSim = new FluidFrameSim(count);
	    	simThread = new Thread(ffSim);
			simThread.start();
			
			String s, s1 = null;
			s = (String) speedComboBox.getSelectedItem();
			s1 = (String) particleComboBox.getSelectedItem(); 
					
			if (s.equals(" 1x "))	speedComboBox.setSelectedItem(" 1x ");
			else if (s.equals(" 2x ")) speedComboBox.setSelectedItem(" 2x ");
			else if (s.equals(" 3x ")) speedComboBox.setSelectedItem(" 3x ");
			else speedComboBox.setSelectedItem(" 4x ");
			
			if (s1.equals(" 1 "))	particleComboBox.setSelectedItem(" 1 ");
			else if (s1.equals(" 2 ")) particleComboBox.setSelectedItem(" 2 ");
			else if (s1.equals(" 3 ")) particleComboBox.setSelectedItem(" 3 ");
			else particleComboBox.setSelectedItem(" 4x ");
			
			startBtn.setEnabled(false);
			pauseBtn.setEnabled(true);
			resumeBtn.setEnabled(false);
			stopBtn.setEnabled(true);
			ruleComboBox.setEnabled(false);
			genCount.setEnabled(false);
			speedComboBox.setEnabled(false);
			particleComboBox.setEnabled(false);
		}
		
			
		else if (ae.getSource() == pauseBtn) {
			
			System.out.println("Pause pressed");
			FluidFrameSim.pauseSimulation();
					
			startBtn.setEnabled(false);
			pauseBtn.setEnabled(false);
			resumeBtn.setEnabled(true);
			stopBtn.setEnabled(true);
			ruleComboBox.setEnabled(false);
			speedComboBox.setEnabled(true);
			particleComboBox.setEnabled(true);
		}
		
		else if (ae.getSource() == resumeBtn) {
			System.out.println("Resume pressed");
			FluidFrameSim.resumeSimulation();
			
			startBtn.setEnabled(false);
			pauseBtn.setEnabled(true);
			resumeBtn.setEnabled(false);
			stopBtn.setEnabled(true);
			ruleComboBox.setEnabled(false);
			speedComboBox.setEnabled(false);
			particleComboBox.setEnabled(false);
		}
		
		else if (ae.getSource() == stopBtn) {
			System.out.println("Stop pressed");
			simThread.stop();
			FluidFrameSim.resumeSimulation();
			
			startBtn.setEnabled(true);
			pauseBtn.setEnabled(false);
			resumeBtn.setEnabled(false);
			stopBtn.setEnabled(false);
			ruleComboBox.setEnabled(true);
			genCount.setEnabled(true);
			speedComboBox.setEnabled(true);
			particleComboBox.setEnabled(true);
		}
		
		else if (ae.getSource() == ruleComboBox) {
			System.out.println("Rule Combo Box pressed");
			
			String s3 = null;
			s3 = (String) ruleComboBox.getSelectedItem();
			System.out.println("Rule Selected: " + s3);
			
			if (s3.equals("2 particle collision"))	checkOption = 2;
			else if (s3.equals("3 particle collision")) checkOption = 3;
			else if (s3.equals("4 particle collision")) checkOption = 4;
			else checkOption = 0;

			ruleComboBox.setEnabled(true);
			speedComboBox.setEnabled(true);
		
		}
		else if (ae.getSource() == speedComboBox) {
			System.out.println("Speed selection Combo Box pressed");
			
			String s4 = null;
			s4 = (String) speedComboBox.getSelectedItem();
			System.out.println("Rule Selected: " + s4);
			
			if (s4.equals(" 1x "))	speedOption = 1;
			else if (s4.equals(" 2x ")) speedOption = 2;
			else if (s4.equals(" 3x ")) speedOption = 3;
			else speedOption = 4;

			speedComboBox.setEnabled(true);
		
		}
		
		else if (ae.getSource() == particleComboBox) {
			System.out.println("Particle size Combo Box pressed");
			
			String s5 = null;
			s5 = (String) particleComboBox.getSelectedItem();
			System.out.println("Particle speed Selected: " + s5);
			
			if (s5.equals(" 1 "))	particleOption = 1;
			else if (s5.equals(" 2 ")) particleOption = 2;
			else if (s5.equals(" 3 ")) particleOption = 3;
			else particleOption = 4;

			speedComboBox.setEnabled(true);
		
		}
		
	}
	
	public static void resetButtons()
	{
		startBtn.setEnabled(true);
		genCount.setEnabled(true);
		ruleComboBox.setEnabled(true);
		pauseBtn.setEnabled(false);
		resumeBtn.setEnabled(false);
		stopBtn.setEnabled(false);
		speedComboBox.setEnabled(true);
		particleComboBox.setEnabled(true);
		FluidFrameSim.resumeSimulation();	
	}

	@Override
	public void windowOpened(WindowEvent e) {
		log.info("Window opened");
	}

	@Override
	public void windowClosing(WindowEvent e) {	
		log.info("Window closing");
	}

	@Override
	public void windowClosed(WindowEvent e) {
		log.info("Window closed");
	}

	@Override
	public void windowIconified(WindowEvent e) {
		log.info("Window iconified");
	}

	@Override
	public void windowDeiconified(WindowEvent e) {	
		log.info("Window deiconified");
	}

	@Override
	public void windowActivated(WindowEvent e) {
		log.info("Window activated");
	}

	@Override
	public void windowDeactivated(WindowEvent e) {	
		log.info("Window deactivated");
	}
	
	/**
	 * ATApp application starting point
	 * @param args
	 */
	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				ATApp atapp = new ATApp();
				log.info("ATApp started");
			}
		});
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

	

}
